package com.sjj.vip.spring.framework.aop;

import lombok.Data;


@Data
public class SJJAopConfig {
    private String pointCut;
    private String aspectBefore;
    private String aspectAfter;
    private String aspectClass;
    private String aspectAfterThrow;
    private String aspectAfterThrowingName;
}
