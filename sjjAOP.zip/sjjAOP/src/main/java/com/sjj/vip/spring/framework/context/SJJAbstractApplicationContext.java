package com.sjj.vip.spring.framework.context;

/**
 * @ClassName SJJAbstractApplicationContext
 * @Description TODO
 * Author shengjunjie
 * Date 2019/4/26 16:07
 **/
public abstract class SJJAbstractApplicationContext {
    //�ܱ�����ֻ�ṩ��������д
    public void refresh() throws Exception {}

}
