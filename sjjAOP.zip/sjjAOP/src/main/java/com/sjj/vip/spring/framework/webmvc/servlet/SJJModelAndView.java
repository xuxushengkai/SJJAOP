package com.sjj.vip.spring.framework.webmvc.servlet;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import java.util.Map;

/**
 * @ClassName SJJModelAndView
 * @Description TODO
 * Author shengjunjie
 * Date 2019/4/29 15:43
 **/
@Setter
@Getter
public class SJJModelAndView {
    private String viewName;
    private Map<String,?> model;

    public SJJModelAndView(String viewName) {
        this(viewName,null);
    }

    public SJJModelAndView(String viewName,Map<String,?> model){
        this.viewName = viewName;
        this.model = model;
    }
}
