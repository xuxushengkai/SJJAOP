package com.sjj.vip.spring.demo.action;


import com.sjj.vip.spring.demo.service.IModifyService;
import com.sjj.vip.spring.demo.service.IQueryService;
import com.sjj.vip.spring.framework.annoation.SJJAutowired;
import com.sjj.vip.spring.framework.annoation.SJJController;
import com.sjj.vip.spring.framework.annoation.SJJRequestMapping;
import com.sjj.vip.spring.framework.annoation.SJJRequestParam;
import com.sjj.vip.spring.framework.webmvc.servlet.SJJModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * 公布接口 url
 * @author Tom
 *
 */
@SJJController
@SJJRequestMapping("/web")
public class MyAction {

    @SJJAutowired
    IQueryService queryService;

    @SJJAutowired
    IModifyService modifyService;

    @SJJRequestMapping("/query.json")
    public SJJModelAndView query(HttpServletRequest request, HttpServletResponse response, @SJJRequestParam("name") String name){
        String result = queryService.query(name);
        return out(response,result);
    }

    @SJJRequestMapping("/add*.json")
    public SJJModelAndView add(HttpServletRequest request, HttpServletResponse response, @SJJRequestParam("name") String name,@SJJRequestParam("addr") String addr){
        String result = modifyService.add(name,addr);
        return out(response,result);
    }

    @SJJRequestMapping("/edit.json")
    public SJJModelAndView edit(HttpServletRequest request, HttpServletResponse response, @SJJRequestParam("id") Integer id,@SJJRequestParam("name") String name){
        String result = modifyService.edit(id,name);
        return out(response,result);
    }

    @SJJRequestMapping("/remove.json")
    public SJJModelAndView add(HttpServletRequest request, HttpServletResponse response, @SJJRequestParam("id") Integer id){
        String result = modifyService.remove(id);
        return out(response,result);
    }

    private SJJModelAndView out(HttpServletResponse resp,String result){
        try {
            resp.getWriter().write(result);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }
}
