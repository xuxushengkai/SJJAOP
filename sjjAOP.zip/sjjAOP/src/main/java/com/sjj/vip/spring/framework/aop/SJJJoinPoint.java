package com.sjj.vip.spring.framework.aop;

import java.lang.reflect.Method;

public interface SJJJoinPoint {
    Method getMethod();
    Object[] getArguments();
    Object getThis();
}
