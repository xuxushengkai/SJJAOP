package com.sjj.vip.spring.framework.annoation;


import java.lang.annotation.*;


@Target(ElementType.PARAMETER)
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface SJJRequestParam {
    String value() default "";
}
