package com.sjj.vip.spring.demo.action;


import com.sjj.vip.spring.demo.service.IQueryService;
import com.sjj.vip.spring.framework.annoation.SJJAutowired;
import com.sjj.vip.spring.framework.annoation.SJJController;
import com.sjj.vip.spring.framework.annoation.SJJRequestMapping;
import com.sjj.vip.spring.framework.annoation.SJJRequestParam;
import com.sjj.vip.spring.framework.webmvc.servlet.SJJModelAndView;

import java.util.HashMap;
import java.util.Map;

/**
 * 公布接口
 */
@SJJRequestMapping("/")
@SJJController
public class PageAction {

    @SJJAutowired
    IQueryService queryService;

    @SJJRequestMapping("/first.html")
    public SJJModelAndView query(@SJJRequestParam("student") String student){
        String result = queryService.query(student);
        Map<String,Object> model = new HashMap<String, Object>();
        model.put("student",student);
        model.put("data",result);
        model.put("token","111111");
        return new SJJModelAndView("first.html",model);
    }

}
