package com.sjj.vip.spring.demo.aspect;

import com.sjj.vip.spring.framework.aop.SJJJoinPoint;
import lombok.extern.slf4j.Slf4j;

import java.util.Arrays;

@Slf4j
public class LogAspect {

    public void before(SJJJoinPoint joinPoint){
        //��������е��߼������������Լ�д��
        log.info("Invoker Before Method!!!" +"\nTargetObject:" + joinPoint.getThis() +"\nArgs:" + Arrays.toString(joinPoint.getArguments()));
    }

    //�ڵ���һ������֮��ִ�� after ����
    public void after(SJJJoinPoint joinPoint){
        log.info("Invoker After Method!!!" +
                "\nTargetObject:" + joinPoint.getThis() +
                "\nArgs:" + Arrays.toString(joinPoint.getArguments()));
    }

    public void afterThrowing(SJJJoinPoint joinPoint, Throwable ex){
        log.info("�����쳣" +
                "\nTargetObject:" + joinPoint.getThis() +
                "\nArgs:" + Arrays.toString(joinPoint.getArguments()) +
                "\nThrows:" + ex.getMessage());
    }
}
