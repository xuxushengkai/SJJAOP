package com.sjj.vip.spring.framework.aop;

import java.lang.reflect.Method;

public class SJJAfterThrowingAdvice  extends SJJAbstractAspectJAdvice implements  SJJAdvice,SJJMethodInterceptor{

    private String throwingName;
    private SJJMethodInvocation mi;

    public SJJAfterThrowingAdvice(Method aspectMethod, Object aspectTarget) {
        super(aspectMethod, aspectTarget);
    }

    public void setThrowingName(String throwingName) {
        this.throwingName = throwingName;
    }


    @Override
    public Object invoke(SJJMethodInvocation mi) throws Throwable {
        try {
            return mi.proceed();
        }catch (Throwable ex) {
            invokeAdviceMethod(mi,null,ex.getCause());
            throw ex;
        }
    }
}
