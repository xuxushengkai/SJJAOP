package com.sjj.vip.spring.framework.core;

/**
 * @ClassName SJJBeanFactory
 * @Description TODO
 * Author shengjunjie
 * Date 2019/4/26 15:34
 **/
public interface SJJBeanFactory {
    /**
     * ���� beanName �� IOC �����л��һ��ʵ�� Bean
     * @param beanName
     * @return
     */
    Object getBean(String beanName) throws Exception;

    public Object getBean(Class<?> beanClass) throws Exception;
}
