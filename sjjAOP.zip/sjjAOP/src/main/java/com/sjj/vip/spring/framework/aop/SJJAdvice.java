package com.sjj.vip.spring.framework.aop;

public interface SJJAdvice {
}
