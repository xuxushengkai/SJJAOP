package com.sjj.vip.spring.framework.aop;

public interface SJJMethodInterceptor {
    Object invoke(SJJMethodInvocation mi) throws Throwable;
}
