package com.sjj.vip.spring.framework.aop;

public interface SJJAopProxy {
    Object getProxy();
    Object getProxy(ClassLoader classLoader);
}
