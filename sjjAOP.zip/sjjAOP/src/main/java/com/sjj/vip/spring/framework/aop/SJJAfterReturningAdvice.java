package com.sjj.vip.spring.framework.aop;

import java.lang.reflect.Method;

public class SJJAfterReturningAdvice  extends SJJAbstractAspectJAdvice implements  SJJAdvice,SJJMethodInterceptor{
    private SJJJoinPoint joinPoint;

    public SJJAfterReturningAdvice(Method aspectMethod, Object aspectTarget) {
        super(aspectMethod, aspectTarget);
    }

    @Override
    protected Object invokeAdviceMethod(SJJJoinPoint joinPoint, Object returnValue, Throwable ex) throws Throwable {
        return super.invokeAdviceMethod(joinPoint, returnValue, ex);
    }

    @Override
    public Object invoke(SJJMethodInvocation mi) throws Throwable {
        Object retval = mi.proceed();
        this.joinPoint = mi;
        this.afterReturning(retval,mi.getMethod(),mi.getArguments(),mi.getThis());
        return retval;
    }
    public void afterReturning(Object returnValue, Method method, Object[] args,Object target) throws
            Throwable{
        invokeAdviceMethod(joinPoint,returnValue,null);
    }

}
