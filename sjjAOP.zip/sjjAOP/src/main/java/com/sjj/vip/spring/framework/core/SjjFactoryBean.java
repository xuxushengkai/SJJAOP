package com.sjj.vip.spring.framework.core;

/**
 * @ClassName SjjFactoryBean
 * @Description TODO
 * Author shengjunjie
 * Date 2019/4/26 15:41
 **/
public interface SjjFactoryBean {
}
