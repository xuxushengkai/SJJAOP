package com.sjj.vip.spring.framework.aop;

public class SJJCglibAopProxy implements SJJAopProxy {

    private SJJAdvisedSupport config;

    public SJJCglibAopProxy(SJJAdvisedSupport config){
        this.config = config;
    }

    @Override
    public Object getProxy() {
        return null;
    }

    @Override
    public Object getProxy(ClassLoader classLoader) {
        return null;
    }
}
