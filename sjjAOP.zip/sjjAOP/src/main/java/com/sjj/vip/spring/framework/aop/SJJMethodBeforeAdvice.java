package com.sjj.vip.spring.framework.aop;

import java.lang.reflect.Method;

public class SJJMethodBeforeAdvice extends SJJAbstractAspectJAdvice implements  SJJAdvice,SJJMethodInterceptor{
    private SJJJoinPoint joinPoint;

    public SJJMethodBeforeAdvice(Method aspectMethod, Object target) {
        super(aspectMethod, target);
    }

    public void before(Method method, Object[] args, Object target) throws Throwable {
        invokeAdviceMethod(this.joinPoint,null,null);
    }

    @Override
    public Object invoke(SJJMethodInvocation mi) throws Throwable {
       this.joinPoint = mi;
       this.before(mi.getMethod(),mi.getArguments(),mi.getThis());
       return mi.proceed();
    }
}
